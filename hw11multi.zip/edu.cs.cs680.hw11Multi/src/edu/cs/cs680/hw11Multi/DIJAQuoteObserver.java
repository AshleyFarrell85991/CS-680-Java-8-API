package edu.cs.cs680.hw11Multi;

public interface DIJAQuoteObserver {

	public void updateDIJA(DIJAEvent event);
}
