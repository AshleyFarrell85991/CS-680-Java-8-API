package edu.cs.cs680.hw11Multi;

public interface StockQuoteObserver {

	public void UpdateStock(StockEvent event);
}
