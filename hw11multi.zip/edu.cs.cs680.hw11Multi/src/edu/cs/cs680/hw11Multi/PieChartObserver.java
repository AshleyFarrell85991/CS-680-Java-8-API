package edu.cs.cs680.hw11Multi;

public class PieChartObserver implements StockQuoteObserver,DIJAQuoteObserver {

	@Override
	public void updateDIJA(DIJAEvent event) {
		System.out.println(event.getDjia());			
	}

	@Override
	public void UpdateStock(StockEvent event) {
		System.out.println(event.getTicker()+ "  "+ event.getQuote());	
	}

}
