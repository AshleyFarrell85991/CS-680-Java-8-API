package edu.cs.cs680.hw11Multi;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class StockQuoteObserverable {
	private ArrayList<StockQuoteObserver>  StockQuoteobservers;
	private Set<StockEvent> data = new HashSet<StockEvent>();
	
	public Set<StockEvent> getData() {
		return data;
	}
	public StockQuoteObserverable() {
		StockQuoteobservers = new  ArrayList<StockQuoteObserver> ();
	}
	public void addObservers(StockQuoteObserver o) {
		StockQuoteobservers.add(o);
	}
	
	public void notifyObservers(StockEvent arg) {
		
		data.add(arg);
		for (int counter = 0; counter < StockQuoteobservers.size(); counter++)
		{ 
			StockQuoteobservers.get(counter).UpdateStock(arg);
	     }  
	
	
}}