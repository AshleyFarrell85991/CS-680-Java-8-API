package edu.cs.cs680.hw11Multi;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class DIJAQuoteObservable {

	private ArrayList<DIJAQuoteObserver>  DJIAQuoteobservers;
	private Set<DIJAEvent> data = new HashSet<DIJAEvent>();
	
	public DIJAQuoteObservable() {
		DJIAQuoteobservers = new ArrayList<DIJAQuoteObserver> ();
	}
	
	public Set<DIJAEvent> getData() {
		return data;
	}
	
	public void addObservers(DIJAQuoteObserver o) {
		
		DJIAQuoteobservers.add(o);
	}
	public void notifyObservers(DIJAEvent arg) {
		
		data.add(arg);
			for (int counter = 0; counter < DJIAQuoteobservers.size(); counter++)
			{ 
				DJIAQuoteobservers.get(counter).updateDIJA(arg);
		     }  
		
		
	}
}
