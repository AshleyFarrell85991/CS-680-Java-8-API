package edu.cs.cs680.hw11Multi;

public class DIJAEvent {
	private float djia;
	
	public float getDjia() {
		return djia;
	}

	public void setDjia(float djia) {
		this.djia = djia;
	}

	public DIJAEvent(float djia)
	{
		this.djia = djia;
	}
}
