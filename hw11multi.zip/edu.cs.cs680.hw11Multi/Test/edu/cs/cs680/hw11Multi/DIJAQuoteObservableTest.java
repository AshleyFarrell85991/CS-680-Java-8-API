package edu.cs.cs680.hw11Multi;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

class DIJAQuoteObservableTest {

	@Test
	void test() {
		DIJAQuoteObservable dJIAQuoteObservable = new DIJAQuoteObservable();
		 Set<Float> actual = new HashSet<Float>();
		 Set<Float> expected = new HashSet<Float>();
		 
	
		 dJIAQuoteObservable.addObservers(new PieChartObserver());		
			dJIAQuoteObservable.addObservers(new TableObserver());
			dJIAQuoteObservable.addObservers(new ThreeDObserver());
	
	
			dJIAQuoteObservable.notifyObservers(new DIJAEvent(70));
			dJIAQuoteObservable.notifyObservers(new DIJAEvent(80));
			dJIAQuoteObservable.notifyObservers(new DIJAEvent(90));
			
			
			for (DIJAEvent d : dJIAQuoteObservable.getData()) 
			{

				actual.add(d.getDjia());

			}
			expected.add((float) 70);
			expected.add((float) 80);
			expected.add((float) 90);
		
			assertTrue(actual.containsAll(expected));
	
	
	}

}
