package edu.cs.cs680.hw13;

public interface Command {
	public void execute();

	
}
