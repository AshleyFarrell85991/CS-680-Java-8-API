package edu.cs.cs680.hw13;


public interface Comparator {
	public abstract int compare(FSElement o1, FSElement o2);

}
