package edu.umb.cs.cs680.hw14;
@FunctionalInterface

public interface ComparatorCar {
public abstract void compare(Car o1, Car o2);
}
