package edu.umb.cs.cs680.hw14;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.function.Function;


public abstract class CarLambda implements ComparatorCar{

	public static void main(String[] args) {

ArrayList<Car> cars = new ArrayList<Car>();
//cars.add(new Car(50000,2019,10000));
//cars.add(new Car(2000,1999,1050000));
//cars.add(new Car(8000,2009,55000));
//cars.add(new Car(1000,2017,45000));
//cars.add(new Car(3000,2015,30700));
//cars.add(new Car(2500,2001,80000));
//




for(Car c:cars)
{
	int dominationCount=0;
	for(Car c1:cars) {
		if(c.getMileage() > c1.getMileage() && c.getPrice() > c1.getPrice() && c.getYear() < c1.getYear()) {
			dominationCount++;
		}else if(c.getMileage() == c1.getMileage() && c.getPrice() == c1.getPrice() && c.getYear() == c1.getYear()) {
			
		}
		else if(c.getMileage() == c1.getMileage() && (c.getPrice() > c1.getPrice() || c.getYear() < c1.getYear())) {
			dominationCount++;
		}else if((c.getMileage() > c1.getMileage() || c.getYear() < c1.getYear()) && c.getPrice() == c1.getPrice()) {
			dominationCount++;
		}else if((c.getMileage() > c1.getMileage() || c.getPrice() > c1.getPrice()) && c.getYear() == c1.getYear()) {
			dominationCount++;
		}
		
	}
	
	c.setDominationCount(dominationCount);
}








Collections.sort(cars,Comparator.comparing(
		(Car car)-> car.getPrice()));
System.out.println("\n");
System.out.println("Price Comparison");
for(Car c:cars)
{
	System.out.print(c.getPrice()+" , ");
}

		
///Year Lambda
Collections.sort(cars, Comparator.comparing(
		(Car car)-> car.getYear()));
System.out.println("\n");
System.out.println("Year Comparison");
for(Car c: cars)
	
{
System.out.println(c.getYear()+" , ");}
		
	
	//Year Reverse
	Collections.sort(cars, Comparator.comparing(
			(Car car)-> car.getYear()).reversed());
	System.out.println("\n");
	System.out.println("Reversed Order Comparison");
	for(Car u:cars)
	{
		System.out.print(u.getYear()+" , ");
	}
	
	//Mileage
	Collections.sort(cars, Comparator.comparing(
			(Car car)-> car.getMileage()));
	System.out.println("\n");
	System.out.println("Mileage Comparison");
	for(Car c: cars)
		
	{
	System.out.println(c.getMileage()+" , ");}
			
		//Mileage Reverse
	
	Collections.sort(cars, Comparator.comparing(
			(Car car)-> car.getYear()).reversed());
	System.out.println("\n");
	System.out.println("Mileage Comparison Reverse");
	for(Car c: cars)
	
	{
		System.out.println(c.getMileage()+" , ");}
	


	
	///Pareto sort 
	Collections.sort(cars, Comparator.comparing(
			(Car car)-> car.getDominationCount()));
			System.out.println("\n");
			System.out.println("Pareto:");
			for(Car c:cars)
			{
				System.out.println(c.getDominationCount());
			}	
		
			///Pareto Reverse 
			
			Collections.sort(cars, Comparator.comparing(
					(Car car)-> car.getDominationCount()).reversed());
					System.out.println("\n");
					System.out.println("Pareto:");
					for(Car c:cars)
					{
						System.out.println(c.getDominationCount());
					}		
			




}}