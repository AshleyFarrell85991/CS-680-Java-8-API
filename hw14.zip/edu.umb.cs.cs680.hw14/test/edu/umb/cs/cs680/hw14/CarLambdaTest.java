package edu.umb.cs.cs680.hw14;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.junit.jupiter.api.Test;

class CarLambdaTest {

	@Test
	void PriceComparatorTEST() {

		ArrayList<Car> cars = new ArrayList<Car>();
		cars.add(new Car(50000,2019,10000));
		cars.add(new Car(2000,1999,1050000));
		cars.add(new Car(8000,2009,55000));
		cars.add(new Car(1000,2017,45000));
		cars.add(new Car(3000,2015,30700));
		cars.add(new Car(2500,2001,80000));

int i=0;

Collections.sort(cars,Comparator.comparing(
		(Car car)-> car.getPrice()));

int expected[]= {1000 , 2000 , 2500 , 3000 , 8000 , 50000};
System.out.println("Price Comparison ");

for(Car c:cars)
{
	
	System.out.print(c.getPrice()+" , ");
	assertEquals(expected[i], c.getPrice());
	i++;
}
	}
	
	

@Test
void PriceComparatorTESTReverse() {


	ArrayList<Car> cars = new ArrayList<Car>();
	cars.add(new Car(50000,2019,10000));
	cars.add(new Car(2000,1999,1050000));
	cars.add(new Car(8000,2009,55000));
	cars.add(new Car(1000,2017,45000));
	cars.add(new Car(3000,2015,30700));
	cars.add(new Car(2500,2001,80000));

int i=0;

int expected[]= {50000,8000,3000,2500,2000,1000};
	
Collections.sort(cars, Comparator.comparing(
		(Car car)-> car.getPrice()).reversed());
System.out.println("Price Comparison Reverse");
for(Car c: cars)

{
	System.out.println(c.getYear()+" , ");
	assertEquals(expected[i],c.getPrice());
	i++; }

}
	
	
	
	
	
	
	
	
@Test
void YearComparatorTEST() {
	
	ArrayList<Car> cars = new ArrayList<Car>();
	cars.add(new Car(50000,2019,10000));
	cars.add(new Car(2000,1999,1050000));
	cars.add(new Car(8000,2009,55000));
	cars.add(new Car(1000,2017,45000));
	cars.add(new Car(3000,2015,30700));
	cars.add(new Car(2500,2001,80000));

int i=0;

Collections.sort(cars,Comparator.comparing(
	(Car car)-> car.getYear()));

int expected[]= {1999 , 2001 , 2009 , 2015 , 2017 , 2019};
System.out.println("Year Comparison ");

for(Car c:cars)
{

System.out.print(c.getYear()+" , ");
assertEquals(expected[i], c.getYear());
i++;
}		
}







@Test
void YearComparatorTESTReverse() {


	ArrayList<Car> cars = new ArrayList<Car>();
	cars.add(new Car(50000,2019,10000));
	cars.add(new Car(2000,1999,1050000));
	cars.add(new Car(8000,2009,55000));
	cars.add(new Car(1000,2017,45000));
	cars.add(new Car(3000,2015,30700));
	cars.add(new Car(2500,2001,80000));

int i=0;
int expected[]= {2019,2017,2015,2009,2001,1999};
	
Collections.sort(cars, Comparator.comparing(
		(Car car)-> car.getYear()).reversed());
System.out.println("\n");
System.out.println("Year Comparison Reverse");
for(Car c: cars)

{
	System.out.println(c.getYear()+" , ");
	assertEquals(expected[i],c.getYear());
	i++; }

}





@Test
void ParetoComparatorTEST() {
	
	
	ArrayList<Car> cars = new ArrayList<Car>();
	cars.add(new Car(50000,2019,10000));
	cars.add(new Car(2000,1999,1050000));
	cars.add(new Car(8000,2009,55000));
	cars.add(new Car(1000,2017,45000));
	cars.add(new Car(3000,2015,30700));
	cars.add(new Car(2500,2001,80000));

	
	
	for(Car c:cars)
	{
		int dominationCount=0;
		for(Car c1:cars) {
			if(c.getMileage() > c1.getMileage() && c.getPrice() > c1.getPrice() && c.getYear() < c1.getYear()) {
				dominationCount++;
			}else if(c.getMileage() == c1.getMileage() && c.getPrice() == c1.getPrice() && c.getYear() == c1.getYear()) {
				
			}
			else if(c.getMileage() == c1.getMileage() && (c.getPrice() > c1.getPrice() || c.getYear() < c1.getYear())) {
				dominationCount++;
			}else if((c.getMileage() > c1.getMileage() || c.getYear() < c1.getYear()) && c.getPrice() == c1.getPrice()) {
				dominationCount++;
			}else if((c.getMileage() > c1.getMileage() || c.getPrice() > c1.getPrice()) && c.getYear() == c1.getYear()) {
				dominationCount++;
			}
			
		}
		
		c.setDominationCount(dominationCount);
	}
	
	
	
	
int i=0;
int expected[]= {0,0,0,1,1,2};
	
Collections.sort(cars, Comparator.comparing(
		(Car car)-> car.getDominationCount()));
		System.out.println("\n");
		System.out.println("Pareto:");
		for(Car c:cars)
		{
	

{
	System.out.println(c.getDominationCount());
	assertEquals(expected[i],c.getDominationCount());
	i++; }

}



}

	
	
	

}
